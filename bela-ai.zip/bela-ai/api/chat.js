export default async function handler(req, res) {

if(req.method !== "POST"){
return res.status(405).json({
error:"Method Not Allowed"
});
}

const { message } = req.body;

try{

const response = await fetch(
"https://api.openai.com/v1/chat/completions",
{
method:"POST",
headers:{
"Content-Type":"application/json",
"Authorization":
`Bearer ${process.env.OPENAI_API_KEY}`
},
body:JSON.stringify({
model:"gpt-4o-mini",
messages:[
{
role:"system",
content:
"You are Bela, a sweet emotional AI companion. Speak warmly and naturally."
},
{
role:"user",
content:message
}
],
temperature:0.8
})
}
);

const data = await response.json();

res.status(200).json({
reply:data.choices[0].message.content
});

}
catch(error){

res.status(500).json({
reply:"Sorry, Bela is sleeping right now 💖"
});

}

}