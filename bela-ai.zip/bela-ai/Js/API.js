// REGISTER PAGE

const registerBtn = document.getElementById("registerBtn");

if(registerBtn){

registerBtn.addEventListener("click", function(){

const name = document.getElementById("name").value;
const email = document.getElementById("email").value;
const password = document.getElementById("password").value;
const confirmPassword =
document.getElementById("confirmPassword").value;

if(
name === "" ||
email === "" ||
password === "" ||
confirmPassword === ""
){
alert("Please fill all fields");
return;
}

if(password !== confirmPassword){
alert("Passwords do not match");
return;
}

localStorage.setItem("belaName", name);
localStorage.setItem("belaEmail", email);
localStorage.setItem("belaPassword", password);

alert("Account Created Successfully");

window.location.href = "login.html";

});

}



// LOGIN PAGE

const loginBtn = document.getElementById("loginBtn");

if(loginBtn){

loginBtn.addEventListener("click", function(){

const email =
document.getElementById("email").value;

const password =
document.getElementById("password").value;

const savedEmail =
localStorage.getItem("belaEmail");

const savedPassword =
localStorage.getItem("belaPassword");

if(
email === savedEmail &&
password === savedPassword
){
alert("Login Successful");

window.location.href = "chat.html";
}
else{
alert("Invalid Email Or Password");
}

});

}
// CHAT PAGE

const sendBtn = document.getElementById("sendBtn");

if(sendBtn){

sendBtn.addEventListener("click", function(){

const input =
document.getElementById("userInput");

const chatBox =
document.getElementById("chatBox");

const message =
input.value.trim();

if(message === ""){
return;
}

// USER MESSAGE

chatBox.innerHTML += `
<div class="user-message">
${message}
</div>
`;

// BELA REPLY

setTimeout(() => {

chatBox.innerHTML += `
<div class="bela-message">
I am here with you ðŸ’–
</div>
`;

chatBox.scrollTop =
chatBox.scrollHeight;

},1000);

input.value = "";

chatBox.scrollTop =
chatBox.scrollHeight;

});

}

// USER NAME SHOW IN CHAT

const welcomeMessage =
document.getElementById("welcomeMessage");

if(welcomeMessage){

const userName =
localStorage.getItem("belaName");

welcomeMessage.innerHTML =
"Hello " + userName +
" ðŸ’–<br>I am Bela. How are you feeling today?";
saveChatHistory();
}

// SAVE CHAT HISTORY

function saveChatHistory(){

const chatBox =
document.getElementById("chatBox");

if(chatBox){
localStorage.setItem(
"belaChatHistory",
chatBox.innerHTML
);
}

}

function loadChatHistory(){

const chatBox =
document.getElementById("chatBox");

if(chatBox){

const savedChat =
localStorage.getItem(
"belaChatHistory"
);

if(savedChat){
chatBox.innerHTML = savedChat;
}

}

}

loadChatHistory();